
        function hideshow_onclick(){
            document.getElementById("firstname").style.display="none";
            document.getElementById("lastname").style.display="none";
            document.getElementById("phone").style.display="none";
            document.getElementById("fname").style.display="";
            document.getElementById("lname").style.display="";
            document.getElementById("phone1").style.display="";
            document.getElementById("fname").innerHTML=document.getElementById("firstname").value;
            document.getElementById("lname").innerHTML=document.getElementById("lastname").value;
            document.getElementById("phone1").innerHTML=document.getElementById("phone").value;
            document.getElementById("hideshow").style.display="none";
            document.getElementById("hideshow2").style.display="";
            }
        function hideshow2_onclick(){
            document.getElementById("firstname").style.display="";
            document.getElementById("lastname").style.display="";
            document.getElementById("phone").style.display="";
            document.getElementById("fname").style.display="none";
            document.getElementById("lname").style.display="none";
            document.getElementById("phone1").style.display="none";
            document.getElementById("firstname").value=document.getElementById("fname").innerHTML;
            document.getElementById("lastname").value=document.getElementById("lname").innerHTML;
            document.getElementById("phone").value=document.getElementById("phone1").innerHTML;
            document.getElementById("hideshow").style.display="";
            document.getElementById("hideshow2").style.display="none";
            }
        function send_onclick(){
            var r=confirm("Are you sure you want to send this message?")
            if(r==true){send_mail();}
            else{correct();}
        }
        function send_mail(){
            alert("Your message has been sent");
        }
        function correct(){
            var corrmail = prompt("Please enter your correct mail");
            document.getElementById("mail").value=corrmail;
        }
        function altname_onchange(){
            document.getElementById("namefamily").innerText=document.getElementById("altname").value;
        }            
